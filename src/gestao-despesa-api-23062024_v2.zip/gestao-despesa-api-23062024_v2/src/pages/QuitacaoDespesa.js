import React, { useState } from 'react';
import { StyleSheet, View, Alert } from 'react-native';
import { Appbar, TextInput, Button, Text } from 'react-native-paper';
import moment from 'moment';
import Container from './../components/Container';
import Header from './../components/Header';
import Body from './../components/Body';
import Input from './../components/Input';
import {
  updatePagamento,
  insertPagamento,
  deletePagamento,
  getExpenses,
} from '../services/pagamentos.services';

const QuitacaoDespesa = () => {
  const [despesaId, setDespesaId] = useState('');
  const [usuarioId, setUsuarioId] = useState('');

  const handleQuitarDespesa = () => {
    if (!despesaId || !usuarioId) {
      Alert.alert('Atenção!', 'Obrigatório informar o ID da despesa e o ID do usuário!');
    } else {
      insertPagamento({
        expenseId: parseInt(despesaId),
        userId: parseInt(usuarioId),
        date: moment().utc().format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      }).then((res) => {
        Alert.alert('Sucesso!', 'Despesa quitada com sucesso!');
        setDespesaId('');
        setUsuarioId('');
      }).catch((error) => {
        Alert.alert('Erro!', 'Não foi possível quitar a despesa. Tente novamente.');
      });
    }
  };

  return (
    <Container>
      <Header title={'Quitar Despesa'} />
      <Body>
        <Input
          label="ID da Despesa"
          value={despesaId}
          keyboardType="numeric"
          onChangeText={(text) => setDespesaId(text)}
        />
        <Input
          label="ID do Usuário"
          value={usuarioId}
          keyboardType="numeric"
          onChangeText={(text) => setUsuarioId(text)}
        />
        <Button mode="contained" onPress={handleQuitarDespesa}>
          Quitar Despesa
        </Button>
      </Body>
    </Container>
  );
};

//const styles = StyleSheet.create({
//  text: {
//    textAlign: 'center',
//    margin: 8,
//  },
//});

export default QuitacaoDespesa;

