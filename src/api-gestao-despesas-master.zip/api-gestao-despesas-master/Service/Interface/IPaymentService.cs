﻿//using api_gestao_despesas.DTO.Request;
//using api_gestao_despesas.DTO.Response;

//namespace api_gestao_despesas.Service.Interface
//{
//    public interface IPaymentService
//    {
//        Task<PaymentResponseDTO> Create(PaymentRequestDTO paymentDTO);
//        Task<List<PaymentResponseDTO>> GetAll();
//        Task<PaymentResponseDTO> GetById(int id);
//        Task<PaymentResponseDTO> Update(int id, PaymentRequestDTO paymentDTO);
//        Task<PaymentResponseDTO> Delete(int id);
//    }
//}
