﻿//using api_gestao_despesas.DTO.Request;
//using api_gestao_despesas.DTO.Response;

//namespace api_gestao_despesas.Service.Interface
//{
//    public interface IExpenseService
//    {
//        Task<ExpenseResponseDTO> Create(ExpenseRequestDTO expenseDTO);
//        Task<List<ExpenseResponseDTO>> GetAll();
//        Task<ExpenseResponseDTO> GetById(int id);
//        Task<ExpenseResponseDTO> Update(int id, ExpenseRequestDTO expenseDTO);
//        Task<ExpenseResponseDTO> Delete(int id);
//    }
//}
