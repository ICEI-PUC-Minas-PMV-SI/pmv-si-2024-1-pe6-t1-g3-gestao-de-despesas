﻿using Microsoft.AspNetCore.Authorization;

namespace api_gestao_despesas.Properties
{
    public class OwnerRequirement : IAuthorizationRequirement
    {
    }
}
